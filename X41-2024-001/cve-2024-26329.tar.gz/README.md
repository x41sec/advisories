Run with:

```bash
docker build . -t chilkat_poc
docker run -it chilkat_poc
```

